from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from os import path
from flask_login import LoginManager

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = "testing123123123"
    
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('errors/404.html', title='Page not found')

    from .views import views
    app.register_blueprint(views, url_prefix="/")
    return app

app = create_app()